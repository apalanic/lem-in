#include "../libft/libft.h"

int	main(void)
{
	char *line;

	while (get_next_line(3, &line) == 1)
		ft_printf("%s", line);
	free (line);
	return (0);
}